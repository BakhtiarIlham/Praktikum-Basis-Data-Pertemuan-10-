CREATE DATABASE praktikum4;
use praktikum4;

CREATE TABLE stok_barang (
    id_barang INT PRIMARY KEY,
    nama_barang VARCHAR(50),
    kategori VARCHAR(30),
    harga INT,
    stok INT
);

SELECT * FROM stok_barang;

INSERT INTO stok_barang (id_barang, nama_barang, kategori, harga, stok) VALUES
(1, 'Pensil 2B',       'ATK',   3000,   50),
(2, 'Buku Tulis',      'ATK',  10000,   30),
(3, 'Penghapus',       'ATK',   2000,   70),
(4, 'Spidol',          'ATK',  15000,   20),
(5, 'Bolpoin Hitam',   'ATK',   5000,   40),
(6, 'Map Plastik',     'ATK',   4000,   25);

SELECT AVG(harga) AS rata_harga
FROM stok_barang;

SELECT COUNT(*) AS jumlah_barang
FROM stok_barang;

SELECT SUM(stok) AS total_stok
FROM stok_barang;

SELECT MAX(harga) AS harga_tertinggi
FROM stok_barang;

SELECT MIN(harga) AS harga_terendah
FROM stok_barang;

SELECT *
FROM stok_barang
ORDER BY harga DESC;

SELECT kategori, SUM(stok) AS total_stok
FROM stok_barang
GROUP BY kategori;

SELECT kategori, SUM(stok) AS total_stok
FROM stok_barang
GROUP BY kategori
HAVING SUM(stok) > 100;
