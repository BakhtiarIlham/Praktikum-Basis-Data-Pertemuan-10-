-- Data untuk table jurusan
INSERT INTO jurusan (kode_jurusan, nama_jurusan, ketua_jurusan)
VALUES
('KD01', 'Sistem Informasi', 'Harnaningrum,S.Si'),
('KD02', 'Teknik Informatika', 'EnnySela,S.Kom.,M.Kom'),
('KD03', 'Tekhnik Komputer', 'Berta Bednar,S.Si,M.T');

-- Data untuk table biodata
INSERT INTO biodata (no_mahasiswa, kode_jurusan, nama_mahasiswa, alamat, ipk)
VALUES
('210089', 'KD01', 'Rina Gunawan', 'Denpasar', 3.0),
('210090', 'KD03', 'Gani Suprapto', 'Singaraja', 3.5),
('210012', 'KD02', 'Alexandra', 'Nusa Dua', 3.0),
('210099', 'KD02', 'Nadine', 'Gianyar', 3.2),
('210002', 'KD01', 'Rizal Samurai', 'Denpasar', 3.7);

-- Menambahkan Data Baru (Kode Jurusan KD04)
INSERT INTO jurusan (kode_jurusan, nama_jurusan, ketua_jurusan)
VALUES ('KD04', 'Teknik Elektro', 'Agus Santoso,S.T,M.T');

INSERT INTO biodata (no_mahasiswa, kode_jurusan, nama_mahasiswa, alamat, ipk)
VALUES ('210101', 'KD04', 'Dewi Ayu', 'Tabanan', 3.4);

-- Melakukan Perubahan (UPDATE)
UPDATE biodata
SET nama_mahasiswa = 'Rina Gunawan Astuti'
WHERE nama_mahasiswa = 'Rina Gunawan';

UPDATE jurusan
SET kode_jurusan = 'KM01'
WHERE kode_jurusan = 'KD01';

-- Juga perlu update di tabel biodata agar relasinya tetap sesuai:
UPDATE biodata
SET kode_jurusan = 'KM01'
WHERE kode_jurusan = 'KD01';

UPDATE biodata
SET no_mahasiswa = '210098'
WHERE no_mahasiswa = '210089';

UPDATE biodata
SET ipk = 3.3
WHERE ipk = 3.0;

UPDATE jurusan
SET kode_jurusan = 'KD05'
WHERE kode_jurusan = 'KD03';

-- Update juga di tabel biodata agar konsisten
UPDATE biodata
SET kode_jurusan = 'KD05'
WHERE kode_jurusan = 'KD03';




