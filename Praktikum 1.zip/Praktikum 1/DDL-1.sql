CREATE DATABASE db_mahasiswa;
USE db_mahasiswa;

CREATE TABLE jurusan (
  kode_jurusan VARCHAR(5) PRIMARY KEY,
  nama_jurusan VARCHAR(50),
  ketua_jurusan VARCHAR(50)
);
	
CREATE TABLE biodata (
  no_mahasiswa CHAR(6) PRIMARY KEY,
  kode_jurusan VARCHAR(5),
  nama_mahasiswa VARCHAR(50),
  alamat VARCHAR(50),
  ipk DECIMAL(2,1),
  FOREIGN KEY (kode_jurusan) REFERENCES jurusan(kode_jurusan)
);

SELECT * FROM jurusan;
SELECT * FROM biodata;
