USE db_mahasiswa;

SELECT * FROM biodata;
SELECT * FROM jurusan;

SELECT 
    nama_mahasiswa,
    ipk,
    IF(ipk >= 3.00, 'Lulus', 'Tidak Lulus') AS status_kelulusan
FROM biodata;

SELECT 
    nama_mahasiswa,
    IFNULL(kode_jurusan, 'Belum Terdaftar') AS jurusan_fix
FROM biodata;

SELECT 
    nama_mahasiswa,
    ipk,
    NULLIF(ipk, 0) AS ipk_valid
FROM biodata;

SELECT
    nama_mahasiswa,
    ipk,
    CASE
        WHEN ipk >= 3.50 THEN 'Cumlaude'
        WHEN ipk >= 3.00 THEN 'Sangat Baik'
        WHEN ipk >= 2.50 THEN 'Baik'
        ELSE 'Cukup'
    END AS predikat
FROM biodata;

CREATE TEMPORARY TABLE temp_rekap_ipk AS
SELECT 
    b.no_mahasiswa,
    b.nama_mahasiswa,
    b.ipk,
    j.nama_jurusan
FROM biodata b
LEFT JOIN jurusan j ON b.kode_jurusan = j.kode_jurusan;
SELECT * FROM temp_rekap_ipk;
