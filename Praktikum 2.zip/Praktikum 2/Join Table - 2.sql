-- Cartesian Product
SELECT *
FROM biodata, jurusan;

-- Inner Join
SELECT 
  biodata.no_mahasiswa,
  biodata.nama_mahasiswa,
  biodata.ipk,
  jurusan.nama_jurusan,
  jurusan.ketua_jurusan
FROM biodata
INNER JOIN jurusan
  ON biodata.kode_jurusan = jurusan.kode_jurusan;

-- Left Join
SELECT 
  biodata.no_mahasiswa,
  biodata.nama_mahasiswa,
  biodata.kode_jurusan,
  jurusan.nama_jurusan,
  jurusan.ketua_jurusan
FROM biodata
LEFT JOIN jurusan
  ON biodata.kode_jurusan = jurusan.kode_jurusan;

-- Right Join
SELECT 
  jurusan.kode_jurusan,
  jurusan.nama_jurusan,
  jurusan.ketua_jurusan,
  biodata.no_mahasiswa,
  biodata.nama_mahasiswa,
  biodata.ipk
FROM biodata
RIGHT JOIN jurusan
  ON biodata.kode_jurusan = jurusan.kode_jurusan;


-- Perbedaan utama antara LEFT JOIN dan RIGHT JOIN terletak pada arah atau sisi pengambilan data 
-- dari tabel yang digunakan dalam operasi penggabungan. LEFT JOIN akan menampilkan seluruh data 
-- yang berasal dari tabel sebelah kiri, meskipun tidak memiliki pasangan yang cocok di tabel sebelah kanan. 
-- Jika tidak ada pasangan yang sesuai, maka kolom dari tabel kanan akan bernilai NULL. Sebaliknya, RIGHT JOIN 
-- menampilkan seluruh data dari tabel sebelah kanan, dan hanya akan menampilkan data dari tabel kiri jika ada 
-- nilai yang cocok berdasarkan kondisi penggabungan. Bila tidak ada pasangan yang sesuai, maka kolom 
-- dari tabel kiri akan bernilai NULL. Dengan kata lain, perbedaan keduanya hanya pada posisi tabel yang 
-- dijadikan acuan utama dalam menampilkan seluruh datanya. Meskipun hasil akhirnya dapat saling ditukar 
-- dengan mengubah urutan tabel, pemahaman arah penggabungan ini penting untuk memastikan hasil query 
-- sesuai dengan kebutuhan analisis data.