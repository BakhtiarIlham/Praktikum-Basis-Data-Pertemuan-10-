USE db_mahasiswa;

DELIMITER $$
CREATE PROCEDURE GetMahasiswaByKetuaJurusan(IN ketua VARCHAR(100))
BEGIN
    SELECT 
        b.no_mahasiswa,
        b.nama_mahasiswa,
        j.nama_jurusan,
        j.ketua_jurusan,
        j.kode_jurusan
    FROM biodata b
    JOIN jurusan j ON b.kode_jurusan = j.kode_jurusan
    WHERE j.ketua_jurusan LIKE CONCAT('%', ketua, '%');
END $$
DELIMITER ;
CALL GetMahasiswaByKetuaJurusan('Harnaningrum');

DELIMITER $$
CREATE PROCEDURE CariKetuaJurusan(
    IN p_nama VARCHAR(100)
)
BEGIN
    SELECT ketua_jurusan, nama_jurusan
    FROM jurusan
    WHERE ketua_jurusan LIKE CONCAT('%', p_nama, '%');
END $$
DELIMITER ;
CALL CariKetuaJurusan('Berta');

CREATE TABLE log_mahasiswa (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nim VARCHAR(20),
    waktu TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    aksi VARCHAR(50)
);

DELIMITER $$
CREATE TRIGGER trg_log_insert_mahasiswa
AFTER INSERT ON biodata
FOR EACH ROW
BEGIN
    INSERT INTO log_mahasiswa (no_mahasiswa, aksi)
    VALUES (NEW.no_mahasiswa, 'Data mahasiswa ditambahkan');
END $$
DELIMITER ;