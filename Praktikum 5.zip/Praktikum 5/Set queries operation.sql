CREATE DATABASE praktikum5;
use praktikum5;

SELECT * FROM pembelian;
SELECT * FROM kredit;

CREATE TABLE pembelian (
    id_barang INT,
    nama_pembeli VARCHAR(50),
    jumlah_pembelian INT
);

CREATE TABLE kredit (
    id_barang INT,
    nama_pembeli VARCHAR(50),
    jumlah_retur INT
);

INSERT INTO pembelian VALUES
(101, 'Andi', 3),
(102, 'Budi', 5),
(103, 'Citra', 2),
(104, 'Dewi', 5),
(105, 'Eka', 1),
(106, 'Budi', 4);

INSERT INTO kredit VALUES
(102, 'Budi', 1),
(104, 'Dewi', 2),
(107, 'Fajar', 1),
(101, 'Andi', 1);

SELECT id_barang, nama_pembeli FROM pembelian
UNION
SELECT id_barang, nama_pembeli FROM kredit;

SELECT id_barang, nama_pembeli FROM pembelian
UNION ALL
SELECT id_barang, nama_pembeli FROM kredit;

SELECT p.id_barang, p.nama_pembeli
FROM pembelian p
WHERE EXISTS (
    SELECT 1
    FROM kredit r
    WHERE r.id_barang = p.id_barang
      AND r.nama_pembeli = p.nama_pembeli
);

SELECT p.id_barang, p.nama_pembeli
FROM pembelian p
WHERE NOT EXISTS (
    SELECT 1
    FROM kredit r
    WHERE r.id_barang = p.id_barang
      AND r.nama_pembeli = p.nama_pembeli
);

