CREATE DATABASE praktikum3;
USE praktikum3;

SELECT LOWER('HELLO WORLD') AS hasil;

SELECT UPPER('hello world') AS hasil;

SELECT SUBSTRING('ABCDEFG', 3, 4) AS hasil;   

SELECT LTRIM('   Halo') AS hasil;

SELECT RTRIM('Halo   ') AS hasil;

SELECT RIGHT('ABCDEFG', 3) AS hasil;   

SELECT LEFT('ABCDEFG', 3) AS hasil;    

SELECT REVERSE('ABCDE') AS hasil;      

SELECT CONCAT('A', SPACE(5), 'B') AS hasil;